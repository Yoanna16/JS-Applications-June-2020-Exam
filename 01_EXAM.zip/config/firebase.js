  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyDY41pxeovnpTIE_5Y91yq7-14VSFQGlXg",
    authDomain: "exam08-65fef.firebaseapp.com",
    databaseURL: "https://exam08-65fef.firebaseio.com",
    projectId: "exam08-65fef",
    storageBucket: "exam08-65fef.appspot.com",
    messagingSenderId: "403814208309",
    appId: "1:403814208309:web:a5d3fd6289b91726ee327c",
    measurementId: "G-QLHC7FGER1"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
 