export default {
    header: './view/common/header.hbs',
    footer:  './view/common/footer.hbs'
}